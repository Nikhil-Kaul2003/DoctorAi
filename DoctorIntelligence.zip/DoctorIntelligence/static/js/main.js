// Doctor AI - Main JavaScript file

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Auto-close alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert:not(.alert-warning)');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Symptom form validation
    const symptomForm = document.getElementById('symptomForm');
    if (symptomForm) {
        symptomForm.addEventListener('submit', function(event) {
            const symptomSelect = document.getElementById('symptomSelect');
            const additionalSymptoms = document.getElementById('additionalSymptoms');
            
            // Check if at least one symptom is selected or additional symptoms are provided
            if (symptomSelect.selectedOptions.length === 0 && additionalSymptoms.value.trim() === '') {
                event.preventDefault();
                alert('Please select at least one symptom or describe your symptoms in the text area');
            }
        });
    }

    // Add smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Enhance multi-select usability on mobile
    const multiSelects = document.querySelectorAll('select[multiple]');
    multiSelects.forEach(select => {
        // Add touch-friendly selection
        select.addEventListener('touchend', function(e) {
            const option = e.target;
            if (option.tagName === 'OPTION') {
                option.selected = !option.selected;
                e.preventDefault();
            }
        });
    });
});
