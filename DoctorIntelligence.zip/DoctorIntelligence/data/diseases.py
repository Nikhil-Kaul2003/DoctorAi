# Database of diseases and their information
diseases_data = {
    "Common Cold": {
        "description": "A viral infectious disease of the upper respiratory tract that primarily affects the nose. The throat, sinuses, and larynx may also be affected.",
        "symptoms": ["runny nose", "sore throat", "cough", "sneezing", "headache", "body aches", "mild fever"],
        "precautions": [
            "Rest and ensure adequate sleep",
            "Stay hydrated by drinking plenty of fluids",
            "Use a humidifier to add moisture to the air",
            "Gargle with salt water to relieve a sore throat"
        ],
        "diet": [
            "Chicken soup or warm broths",
            "Citrus fruits high in vitamin C",
            "Honey and ginger tea for sore throat",
            "Stay hydrated with water and herbal teas"
        ],
        "workout": [
            "Light stretching if feeling up to it",
            "Avoid strenuous exercise until symptoms improve",
            "Walking in fresh air when feeling better",
            "Deep breathing exercises to clear airways"
        ],
        "medication": [
            "Over-the-counter pain relievers (acetaminophen, ibuprofen)",
            "Decongestants for nasal congestion",
            "Cough suppressants for persistent cough",
            "Antihistamines may help with runny nose"
        ]
    },
    "Influenza": {
        "description": "A highly contagious viral infection that attacks the respiratory system — your nose, throat, and lungs. It's commonly called the flu.",
        "symptoms": ["high fever", "chills", "body aches", "fatigue", "headache", "cough", "sore throat", "runny nose"],
        "precautions": [
            "Get plenty of rest to help your body fight the infection",
            "Stay home to prevent spreading the virus to others",
            "Wash hands frequently with soap and water",
            "Avoid touching your face, especially your eyes, nose, and mouth"
        ],
        "diet": [
            "Clear broths and soups to stay hydrated",
            "Foods rich in vitamin C like oranges and strawberries",
            "Garlic and ginger for immune support",
            "Avoid caffeine and alcohol which can dehydrate"
        ],
        "workout": [
            "Complete rest during the acute phase",
            "Gentle walking once fever subsides",
            "Gradually return to normal activity as symptoms improve",
            "Listen to your body and don't push too hard"
        ],
        "medication": [
            "Antiviral medications (if prescribed within 48 hours)",
            "Acetaminophen or ibuprofen for fever and pain",
            "Cough suppressants for severe cough",
            "Decongestants for nasal congestion"
        ]
    },
    "Pneumonia": {
        "description": "An infection that inflames the air sacs in one or both lungs, which may fill with fluid or pus, causing cough, fever, chills, and difficulty breathing.",
        "symptoms": ["chest pain", "difficulty breathing", "persistent cough", "fever", "fatigue", "nausea", "vomiting"],
        "precautions": [
            "Complete the full course of prescribed antibiotics",
            "Get plenty of rest to aid recovery",
            "Use a humidifier to ease breathing",
            "Avoid smoking and secondhand smoke"
        ],
        "diet": [
            "Protein-rich foods to support healing",
            "Vitamin C-rich foods to boost immunity",
            "Zinc-containing foods like nuts and seeds",
            "Stay well-hydrated with water and electrolyte drinks"
        ],
        "workout": [
            "Complete rest until acute symptoms resolve",
            "Breathing exercises as recommended by healthcare provider",
            "Gradual return to activity with doctor's approval",
            "Avoid strenuous exercise until fully recovered"
        ],
        "medication": [
            "Antibiotics for bacterial pneumonia",
            "Antiviral medications for viral pneumonia",
            "Pain relievers for chest pain and fever",
            "Cough medicine (only if recommended by doctor)"
        ]
    },
    "Diabetes": {
        "description": "A chronic disease that affects how your body turns food into energy, characterized by high blood sugar levels resulting from either insufficient insulin production or the body's cells not responding properly to insulin.",
        "symptoms": ["excessive thirst", "frequent urination", "unexplained weight loss", "fatigue", "blurred vision", "slow-healing sores"],
        "precautions": [
            "Monitor blood sugar levels regularly",
            "Take medications as prescribed",
            "Maintain a healthy weight",
            "Attend regular check-ups with healthcare providers"
        ],
        "diet": [
            "Focus on low glycemic index foods",
            "Include plenty of fiber from vegetables, fruits, and whole grains",
            "Limit refined carbohydrates and added sugars",
            "Control portion sizes and maintain regular meal times"
        ],
        "workout": [
            "Regular aerobic exercise like walking, swimming, or cycling",
            "Strength training 2-3 times per week",
            "Aim for 150 minutes of moderate exercise weekly",
            "Check blood sugar before, during, and after exercise"
        ],
        "medication": [
            "Insulin therapy (for Type 1 and some Type 2)",
            "Oral diabetes medications (metformin, sulfonylureas)",
            "GLP-1 receptor agonists",
            "Regular blood sugar monitoring supplies"
        ]
    },
    "Hypertension": {
        "description": "A chronic condition in which the blood pressure in the arteries is persistently elevated, putting extra strain on the heart and blood vessels.",
        "symptoms": ["headache", "shortness of breath", "nosebleeds", "flushing", "dizziness", "chest pain"],
        "precautions": [
            "Monitor blood pressure regularly",
            "Take medications as prescribed",
            "Reduce salt intake",
            "Manage stress through relaxation techniques"
        ],
        "diet": [
            "Follow the DASH diet (Dietary Approaches to Stop Hypertension)",
            "Reduce sodium intake to less than 1,500mg daily",
            "Increase potassium-rich foods like bananas and avocados",
            "Limit alcohol consumption"
        ],
        "workout": [
            "Regular cardiovascular exercise like walking, jogging, or cycling",
            "Strength training 2-3 times per week",
            "Aim for 150 minutes of moderate exercise weekly",
            "Include relaxation exercises like yoga or tai chi"
        ],
        "medication": [
            "Diuretics (water pills)",
            "ACE inhibitors",
            "Calcium channel blockers",
            "Beta-blockers"
        ]
    },
    "Asthma": {
        "description": "A chronic disease of the airways in the lungs, characterized by variable and recurring symptoms, reversible airflow obstruction, and bronchospasm.",
        "symptoms": ["wheezing", "shortness of breath", "chest tightness", "coughing", "difficulty sleeping"],
        "precautions": [
            "Identify and avoid asthma triggers",
            "Take medications as prescribed",
            "Use an inhaler correctly",
            "Have an asthma action plan ready"
        ],
        "diet": [
            "Foods rich in antioxidants like fruits and vegetables",
            "Omega-3 fatty acids from fish and flaxseeds",
            "Vitamin D-rich foods",
            "Avoid sulfites and known trigger foods"
        ],
        "workout": [
            "Warm up properly before exercise",
            "Swimming and water exercises are often well-tolerated",
            "Use preventive medications before exercise if needed",
            "Activities with short bursts of exertion like interval training"
        ],
        "medication": [
            "Short-acting beta agonists (rescue inhalers)",
            "Inhaled corticosteroids",
            "Long-acting beta agonists",
            "Leukotriene modifiers"
        ]
    },
    "Migraine": {
        "description": "A neurological condition that causes recurring headaches ranging from moderate to severe, often with symptoms like nausea, weakness, and sensitivity to light and sound.",
        "symptoms": ["throbbing headache", "nausea", "vomiting", "sensitivity to light", "sensitivity to sound", "visual disturbances"],
        "precautions": [
            "Identify and avoid personal triggers",
            "Maintain a regular sleep schedule",
            "Stay hydrated",
            "Practice stress management techniques"
        ],
        "diet": [
            "Maintain regular meal times to prevent hunger",
            "Avoid potential trigger foods (aged cheese, processed foods, etc.)",
            "Stay hydrated with water throughout the day",
            "Consider magnesium-rich foods like dark leafy greens"
        ],
        "workout": [
            "Regular moderate exercise like walking or swimming",
            "Yoga and tai chi for stress reduction",
            "Avoid high-intensity exercise during migraine attacks",
            "Maintain consistent exercise routine"
        ],
        "medication": [
            "Pain relievers (NSAIDs, acetaminophen)",
            "Triptans for acute treatment",
            "CGRP antagonists",
            "Preventive medications if migraines are frequent"
        ]
    },
    "Arthritis": {
        "description": "Inflammation of one or more joints, causing pain and stiffness that can worsen with age. The most common types are osteoarthritis and rheumatoid arthritis.",
        "symptoms": ["joint pain", "joint stiffness", "swelling", "reduced range of motion", "redness around joints"],
        "precautions": [
            "Protect joints during activities",
            "Maintain a healthy weight to reduce joint stress",
            "Use assistive devices when needed",
            "Apply heat or cold to reduce pain and inflammation"
        ],
        "diet": [
            "Anti-inflammatory foods like fatty fish and olive oil",
            "Fruits and vegetables rich in antioxidants",
            "Foods high in omega-3 fatty acids",
            "Limit processed foods and added sugars"
        ],
        "workout": [
            "Low-impact exercises like swimming and cycling",
            "Range-of-motion exercises to maintain flexibility",
            "Strength training with light weights",
            "Gentle stretching and yoga"
        ],
        "medication": [
            "Nonsteroidal anti-inflammatory drugs (NSAIDs)",
            "Disease-modifying antirheumatic drugs (DMARDs) for rheumatoid arthritis",
            "Corticosteroids",
            "Joint lubricants (hyaluronic acid injections)"
        ]
    },
    "Allergic Rhinitis": {
        "description": "An allergic inflammation of the nasal airways that occurs when an allergen, such as pollen, dust, or animal dander is inhaled by a person with a sensitized immune system.",
        "symptoms": ["sneezing", "runny nose", "nasal congestion", "itchy eyes", "itchy throat", "watery eyes"],
        "precautions": [
            "Identify and avoid allergens when possible",
            "Keep windows closed during high pollen seasons",
            "Use air purifiers with HEPA filters",
            "Wash bedding in hot water weekly"
        ],
        "diet": [
            "Foods rich in vitamin C and quercetin (citrus, berries)",
            "Local honey may help with pollen allergies",
            "Anti-inflammatory foods like ginger and turmeric",
            "Stay hydrated to thin mucus secretions"
        ],
        "workout": [
            "Indoor exercise during high pollen days",
            "Swimming in indoor pools",
            "Yoga and breathing exercises",
            "Shower after outdoor activities to remove allergens"
        ],
        "medication": [
            "Antihistamines",
            "Nasal corticosteroids",
            "Decongestants (short-term use)",
            "Leukotriene modifiers"
        ]
    },
    "Gastroesophageal Reflux Disease": {
        "description": "A digestive disorder that affects the lower esophageal sphincter (LES), the ring of muscle between the esophagus and stomach, causing stomach acid to flow back into the esophagus.",
        "symptoms": ["heartburn", "chest pain", "difficulty swallowing", "regurgitation of food", "sour taste in mouth", "chronic cough"],
        "precautions": [
            "Avoid lying down after eating",
            "Elevate the head of your bed",
            "Eat smaller, more frequent meals",
            "Avoid trigger foods like spicy or fatty foods"
        ],
        "diet": [
            "Avoid acidic foods like citrus and tomatoes",
            "Limit coffee, alcohol, and carbonated beverages",
            "Choose lean proteins and non-fatty foods",
            "Include alkaline foods like bananas and melons"
        ],
        "workout": [
            "Low-impact exercises like walking and swimming",
            "Avoid exercises that increase abdominal pressure",
            "Wait 2-3 hours after eating before exercising",
            "Maintain upright position during and after workouts"
        ],
        "medication": [
            "Antacids for quick relief",
            "H2 blockers to reduce acid production",
            "Proton pump inhibitors (PPIs)",
            "Prokinetics to strengthen the lower esophageal sphincter"
        ]
    }
}
